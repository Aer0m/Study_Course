create function substring(text, text, text) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function substring(text, text, text) is 'extract text matching SQL regular expression';

alter function substring(text, text, text) owner to postgres;

