create function quote_literal(anyelement) returns text
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select pg_catalog.quote_literal($1::pg_catalog.text)
$$;

comment on function quote_literal(anyelement) is 'quote a data value for usage in a querystring';

alter function quote_literal(anyelement) owner to postgres;

